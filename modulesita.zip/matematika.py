#konstanta dari phi
phi = 3.14

#Fungsi menghitung luas lingkaran
def luas_lingkaran(r):
  return phi * r * r

#Fungsi menghitung luas_persegi
def luas_persegi(s):
  return s * s