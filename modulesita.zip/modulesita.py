def greeting(Name):
  print('Hello, ' + Name)