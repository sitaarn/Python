person1 = { 
  'Name'    : 'Sita',
  'Age'     : 18,
  'Country' : 'Indonesia'
}