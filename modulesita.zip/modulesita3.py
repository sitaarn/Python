def greeting(Name):
  print('Hello, ' + Name)
  
person1 = { 
  'Name'    : 'Sita',
  'Age'     : 18,
  'Country' : 'Indonesia'
}